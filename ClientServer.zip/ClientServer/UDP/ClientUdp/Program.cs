﻿using System.Net.Sockets;
using System.Net;
using System.Text;

namespace ClientUdp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const string ip = "127.0.0.1";
            const int port = 8082;

            var udpEndPoint = new IPEndPoint(IPAddress.Parse(ip), port);

            var udpSocket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            udpSocket.Bind(udpEndPoint);

            while (true)
            {
                Console.WriteLine("Введите сообщение:");
                var message = Console.ReadLine();

                var serverEndPoint = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8081);
                udpSocket.SendTo(Encoding.UTF8.GetBytes(message),  serverEndPoint);

                var buffer = new byte[256];
                var size = 0;
                var data = new StringBuilder();
                EndPoint senderEndPoint = new IPEndPoint(IPAddress.Any, 0); // сохранение адоеса клиента

                do
                {
                    // Прослушивание:

                    size = udpSocket.ReceiveFrom(buffer, ref senderEndPoint);
                    data.Append(Encoding.UTF8.GetString(buffer));
                }
                while (udpSocket.Available > 0);

                Console.WriteLine(data);
                Console.ReadLine();

            }


            ////------------------------------------

            //// Создаем то, что будем отправлять
            //Console.WriteLine("Введите сообщение:");
            //var message = Console.ReadLine(); 

            //var date = Encoding.UTF8.GetBytes(message); // получили данные

            //// делаем подключение для сокета
            //tcpSocket.Connect(tcpEndPoint);
            //// отправляем данные
            //tcpSocket.Send(date);

            //// ожидаем ответ
            //// Буфер для приема данных (сообщений)
            //var buffer = new byte[256];

            //// Количество реально полученных байтов
            //var size = 0;

            ////  Собираем полученные данные
            //var answer = new StringBuilder();

            //// Получаем наше сообщение
            //do
            //{
            //    size = tcpSocket.Receive(buffer); // получаем реальное кол-во байт (сообщение)
            //    answer.Append(Encoding.UTF8.GetString(buffer, 0, size)); // собираем сообщение

            //}
            //while (tcpSocket.Available > 0); // до тех пор пока в подключении есть данные

            //Console.WriteLine(answer.ToString());

            //// закрываем 
            //tcpSocket.Shutdown(SocketShutdown.Both);
            //tcpSocket.Close();

            //Console.ReadLine();
        }
    }
}