﻿using System;
using System.Net.Sockets;
using System.Net;
using System.Text;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ClientTcp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const string ip = "127.0.0.1";
            const int port = 8080;

            var tcpEndPoint = new IPEndPoint(IPAddress.Parse(ip), port);

            var tcpSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            // Создаем то, что будем отправлять
            Console.WriteLine("Введите сообщение:");
            var message = Console.ReadLine();

            var date = Encoding.UTF8.GetBytes(message); // получили данные

            // делаем подключение для сокета
            tcpSocket.Connect(tcpEndPoint);
            // отправляем данные
            tcpSocket.Send(date);

            // ожидаем ответ
            // Буфер для приема данных (сообщений)
            var buffer = new byte[256];

            // Количество реально полученных байтов
            var size = 0;

            //  Собираем полученные данные
            var answer = new StringBuilder();

            // Получаем наше сообщение
            do
            {
                size = tcpSocket.Receive(buffer); // получаем реальное кол-во байт (сообщение)
                answer.Append(Encoding.UTF8.GetString(buffer, 0, size)); // собираем сообщение

            }
            while (tcpSocket.Available > 0); // до тех пор пока в подключении есть данные

            Console.WriteLine(answer.ToString());

            // закрываем 
            tcpSocket.Shutdown(SocketShutdown.Both);
            tcpSocket.Close();

            Console.ReadLine();

        }
    }
}