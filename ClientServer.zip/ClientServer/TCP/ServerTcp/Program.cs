﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace Lesson18
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const string ip = "127.0.0.1";
            const int port = 8080;

            var tcpEndPoint = new IPEndPoint(IPAddress.Parse(ip), port);

            var tcpSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            // Свяжем сокет для слушания
            tcpSocket.Bind(tcpEndPoint);

            // Запускаем прослушивание
            tcpSocket.Listen(5);

            // Процесс прослушивания
            while (true)
            {
                // Прослушиватель (обработчик приема сообщения)
                var listener = tcpSocket.Accept(); // режим ожидания приема сообщения

                // Буфер для приема данных (сообщений)
                var buffer = new byte[256];

                // Количество реально полученных байтов
                var size = 0;

                //  Собираем полученные данные
                var data = new StringBuilder();

                // Получаем наше сообщение
                do
                {
                    size = listener.Receive(buffer); // получаем реальное кол-во байт (сообщение)
                    data.Append(Encoding.UTF8.GetString(buffer, 0, size)); // собираем сообщение

                }
                while (listener.Available > 0); // до тех пор пока в подключении есть данные

                Console.WriteLine(data); // TODO: проверить ToString()

                // Даем обратный ответ
                listener.Send(Encoding.UTF8.GetBytes("Успех!"));


                listener.Shutdown(SocketShutdown.Both);
                listener.Close();

            }
        }
    }
}